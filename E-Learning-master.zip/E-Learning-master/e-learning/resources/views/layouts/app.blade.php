<!-- Implements HTML structure in other views -->
<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="/css/app.css">
    </head>
    <body>



    </body>
</html>