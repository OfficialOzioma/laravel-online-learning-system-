<!-- Extends HTML structure from layouts/app.blade -->
@extends('layouts.app')
<title>User Settings</title>
@include('inc.course.banner2')
@include('inc.course.settingsbtn')