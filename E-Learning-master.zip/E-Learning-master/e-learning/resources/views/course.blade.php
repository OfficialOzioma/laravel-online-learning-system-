<!-- Extends HTML structure from layouts/app.blade -->
@extends('layouts.app')
<title>Course center</title>
@include('inc.course.banner2')


<div class="container">
@include('inc.course.courselist')
    @include('inc.home.popup')
</div>
