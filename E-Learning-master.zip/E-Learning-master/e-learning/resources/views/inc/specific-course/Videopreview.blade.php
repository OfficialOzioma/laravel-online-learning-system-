<style>

    img{
        display: block;
        margin-left: auto;
        margin-right: auto;
        border-style: solid;
        border-width: 3px;
        border-color: #50b066;
    }
</style>



<div class="container">


    <img src="/img/imageSlide_green.jpg" width="450" height="auto" alt="NO PHOTO" align=""> <!-- //TODO videoimage from DB -->


</div>