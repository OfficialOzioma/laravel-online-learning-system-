<style>
    #banner2 {
        left: 10%;
        display: block;
        margin: 0px 0px;
        width: 100%;
        height: 100px;
        font: normal 20px/40px 'Verdana';
        text-align: center;
        color: black;
        background: #50b066;
    }

    #bt:hover {
        text-decoration: underline;
        color: #5e5e5e;
        cursor: hand;
    }

    #bt{
        margin:25px 100px;
    }



    .link:hover{
        text-decoration: underline;
        color: #5e5e5e;
        cursor: hand;
    }

    .link
    {
        color:black;
        text-decoration: none;
        background-color: none;
    }
</style>

<div id="banner2">


    <div class="col-lg-2" id="bt"><a href="/"><div class="link">Home</div></a></div>

    <div class="col-lg-2" id="bt"><a href="/course"><div class="link">Course Center</div></a></div>

    <div class="col-lg-2" id="bt"><a href="/user/settings"><div class="link">Settings</div></a></div>



</div>

