
<style>
    #progress1 {
        padding: 4px;
        height: 30px;
        width: 100px;
        text-align: center;
        color: orange;
        border: yellow solid 2px;
        border-radius: 20px;
        font-size: 10px;
        font-weight: bold;
    }
</style>


<div id="progress1"><p   >In Progress</p></div>
