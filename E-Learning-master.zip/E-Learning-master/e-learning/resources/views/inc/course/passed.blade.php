<style>
    #passed1 {
        padding: 4px;
        height: 30px;
        width: 100px;
        text-align: center;
        color: #4caf50;
        border: #4caf50 solid 3px;
        border-radius: 20px;
        font-size: 10px;
        font-weight: bold;
    }
</style>


<div id="passed1"><p>Passed!</p></div>
