<style>


    #progress {
        padding: 4px;
        margin: -7px -7px;
        height: 30px;
        width: 100px;
        text-align: center;
        color: orange;
        border: yellow;
        border-style: solid;
        border-radius: 20px;
        background: transparent;
        font-size: 10px;
        font-weight: bold;

    }


</style>


<div id="progress"><p>Do This!</p></div>


