<style>
    .banner {
        left: 0%;
        display: block;
        margin: 0px 0px;
        width: 100%;
        height: 100px;
        font: normal 45px/90px 'Verdana';
        text-align: center;
        color: black;
        background: #50b066;
    }
</style>
    <h1 class="banner">Example banner</h1>
