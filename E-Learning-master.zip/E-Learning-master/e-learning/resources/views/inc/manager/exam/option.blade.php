<style>
    input[type=text]{
        width: 70%;
        padding: 1px 10px;
        margin: 8px 0;
        font: normal 80%/100% 'Verdana';
    }
</style>

<div id="question">
    <input type="text" placeholder="Enter an option here" name="option">
</div>

