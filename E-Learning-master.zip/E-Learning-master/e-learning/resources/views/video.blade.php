<!-- Extends HTML structure from layouts/app.blade -->
@extends('layouts.app')
<title>Video Course</title>
@include('inc.course.banner2')

<div class="container">
    @include('inc.video.videoplayer')
    @include('inc.home.popup')

</div>